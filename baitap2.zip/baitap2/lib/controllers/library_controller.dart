import 'package:get/get.dart';
import '../models/book.dart';
import '../models/employee.dart';

class LibraryController extends GetxController {
  var employees = <Employee>[].obs;
  var books = <Book>[].obs;
  var selectedBooks = <Book>[].obs;
  var selectedEmployee = "".obs;
  var borrowedBooks = <String, List<Book>>{}.obs;

  LibraryController() {
    employees.addAll([
      Employee(name: "Nguyễn Văn A"),
      Employee(name: "Trần Thị B"),
    ]);

    books.addAll([
      Book(title: "Flutter cơ bản"),
      Book(title: "Lập trình Dart"),
    ]);
  }

  void renameEmployee(int index, String newName) {
    employees[index] = Employee(name: newName);
  }

  void renameBook(int index, String newTitle) {
    books[index] = Book(title: newTitle);
  }

  void borrowBooks() {
    if (selectedEmployee.value.isEmpty || selectedBooks.isEmpty) return;

    borrowedBooks[selectedEmployee.value] = List.from(selectedBooks);
    selectedBooks.clear();
  }
}
