class Employee {
  String name;
  Employee({required this.name});
}
