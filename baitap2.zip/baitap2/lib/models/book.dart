class Book {
  String title;
  Book({required this.title});
}
