import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/library_controller.dart';
import '../models/book.dart';

class LibraryManagementScreen extends StatelessWidget {
  final LibraryController controller = Get.put(LibraryController());

  LibraryManagementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Hệ thống Quản lý Thư viện")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Nhân viên"),
            Obx(
              () => DropdownButton<String>(
                value:
                    controller.selectedEmployee.value.isNotEmpty
                        ? controller.selectedEmployee.value
                        : null,
                hint: Text("Chọn nhân viên"),
                onChanged: (String? newValue) {
                  if (newValue != null) {
                    controller.selectedEmployee.value = newValue;
                  }
                },
                items:
                    controller.employees.map((employee) {
                      return DropdownMenuItem<String>(
                        value: employee.name,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Flexible(child: Text(employee.name)),
                            IconButton(
                              icon: Icon(Icons.edit),
                              onPressed: () {
                                TextEditingController textController =
                                    TextEditingController(text: employee.name);
                                Get.defaultDialog(
                                  title: "Đổi tên nhân viên",
                                  content: TextField(
                                    controller: textController,
                                  ),
                                  confirm: ElevatedButton(
                                    onPressed: () {
                                      int index = controller.employees
                                          .indexWhere(
                                            (e) => e.name == employee.name,
                                          );
                                      if (index != -1) {
                                        controller.renameEmployee(
                                          index,
                                          textController.text,
                                        );
                                      }
                                      Get.back();
                                    },
                                    child: Text("Lưu"),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      );
                    }).toList(),
              ),
            ),
            SizedBox(height: 20),
            Text("Danh sách sách"),
            Obx(
              () => Column(
                children:
                    controller.books.map((book) {
                      return ListTile(
                        title: Text(book.title),
                        leading: Checkbox(
                          value: controller.selectedBooks.contains(book),
                          onChanged: (bool? value) {
                            if (value == true) {
                              controller.selectedBooks.add(book);
                            } else {
                              controller.selectedBooks.remove(book);
                            }
                          },
                        ),
                        trailing: IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: () {
                            TextEditingController textController =
                                TextEditingController(text: book.title);
                            Get.defaultDialog(
                              title: "Đổi tên sách",
                              content: TextField(controller: textController),
                              confirm: ElevatedButton(
                                onPressed: () {
                                  int index = controller.books.indexOf(book);
                                  if (index != -1) {
                                    controller.renameBook(
                                      index,
                                      textController.text,
                                    );
                                  }
                                  Get.back();
                                },
                                child: Text("Lưu"),
                              ),
                            );
                          },
                        ),
                      );
                    }).toList(),
              ),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    controller.books.add(Book(title: "Sách mới"));
                  },
                  child: Text("Thêm Sách"),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (controller.books.isNotEmpty) {
                      controller.books.removeLast();
                    }
                  },
                  child: Text("Xóa Sách"),
                ),
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: controller.borrowBooks,
              child: Text("Mượn Sách"),
            ),
            SizedBox(height: 20),
            Text("Danh sách sách đã mượn"),
            Obx(
              () => Column(
                children:
                    controller.borrowedBooks.entries.map((entry) {
                      return ListTile(
                        title: Text("${entry.key} đã mượn"),
                        subtitle: Text(
                          entry.value.map((book) => book.title).join(", "),
                        ),
                      );
                    }).toList(),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Quản lý"),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: "DS Sách"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Nhân viên"),
        ],
      ),
    );
  }
}
